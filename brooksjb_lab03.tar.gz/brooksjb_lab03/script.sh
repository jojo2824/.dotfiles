#!/bin/bash

hostname
whoami
echo "Hello, World!"
pwd
mkdir dirA dirB dirC
ls
touch dirA/fileA dirB/fileB dirC/fileC
ls dirA dirB dirC
rm -r dirA dirB dirC


